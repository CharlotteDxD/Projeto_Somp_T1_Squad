"""
app.py
======
Sompo Predict T1 — Aplicacao principal (entry point).

Roteador da aplicacao. Conecta o gateway de seguranca (Charles) com as
paginas dos demais membros do squad.

Como rodar:
    pip install -r requirements.txt
    streamlit run app.py

Owner: Charles (esqueleto + roteamento)
"""
import time
import streamlit as st

from core_auth import (
    inicializar_sessao,
    tela_login_registro,
    check_permissao,
    fazer_logout,
)
from core_audit import gerar_trilha_auditoria, renderizar_trilha

# === IMPORTS DOS MODULOS DOS MEMBROS ===
# Cada um expoe uma funcao render() (ver pagina_TEMPLATE.py)
import pagina_anthony     # US04 — Edge IoT
import pagina_guilherme   # US06/US08 — Dados + Anomalias
import pagina_gustavo     # US05 — Cloud + IA
import pagina_rafael      # US07 — XAI + Ranking
import dashboard_cliente  # US03 — Painel do Segurado (Charles)


# === CONFIG GLOBAL ===
st.set_page_config(
    page_title="Sompo Predict T1",
    page_icon="🛡️",
    layout="wide",
)

inicializar_sessao()


def main():
    """Roteador principal."""
    # Se nao logado, mostra tela de login
    if not st.session_state.jwt_token:
        tela_login_registro()
        return

    # Sidebar com identidade + navegacao
    st.sidebar.title(f"👤 {st.session_state.usuario_logado}")
    st.sidebar.caption(f"Perfil: **{st.session_state.role_logado}**")
    st.sidebar.markdown("---")

    menu = st.sidebar.radio(
        "Navegacao",
        [
            "🏠 Dashboard Cliente (US03)",
            "📡 Telemetria IoT — Anthony (US04)",
            "📊 Analise de Dados — Guilherme (US06/08)",
            "☁️  Cloud + Treino IA — Gustavo (US05)",
            "🎯 XAI + Ranking Frota — Rafael (US07)",
            "🔥 Stress Test (Admin)",
        ],
    )

    st.sidebar.markdown("---")
    if st.sidebar.button("🚪 Logout"):
        fazer_logout()

    # === ROTEAMENTO ===
    # Cada membro entra com check_permissao + render() da sua pagina.
    # gerar_trilha_auditoria pode ser chamada aqui (entrada) ou dentro do render() (acoes).
    if menu.startswith("🏠"):
        if check_permissao("view_dashboard"):
            dashboard_cliente.render()

    elif menu.startswith("📡"):
        if check_permissao("input_telemetry"):
            pagina_anthony.render()

    elif menu.startswith("📊"):
        if check_permissao("extract_data"):
            pagina_guilherme.render()

    elif menu.startswith("☁️"):
        if check_permissao("train_models"):
            pagina_gustavo.render()

    elif menu.startswith("🎯"):
        if check_permissao("view_dashboard"):
            pagina_rafael.render()

    elif menu.startswith("🔥"):
        if check_permissao("all"):
            tela_stress_test()

    # Trilha de auditoria sempre visivel no rodape (transversal)
    st.markdown("---")
    renderizar_trilha(qtd=10)


def tela_stress_test():
    """Tela de stress test (Admin) — Charles. Demo de RBAC + Auditoria."""
    st.title("🔥 Teste de Stress End-to-End")
    st.markdown(
        "Simula multiplas tentativas de ataque para validar Rate Limit + RBAC + Trilha."
    )

    if st.button("🚨 Executar Ataque Simulado"):
        with st.spinner("Atacando API..."):
            for i in range(1, 6):
                gerar_trilha_auditoria(
                    "STRESS_TEST", f"Tentativa #{i} de invasao mock"
                )
                time.sleep(0.4)
                st.write(f"→ Tentativa {i} processada e logada na trilha.")
        st.success(
            "✅ Teste finalizado. Verifique a trilha de auditoria abaixo."
        )


if __name__ == "__main__":
    main()
