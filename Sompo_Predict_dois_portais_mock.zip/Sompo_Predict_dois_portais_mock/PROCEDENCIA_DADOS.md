# Procedência dos dados — apoio à revisão final

Gerado por `auditoria_procedencia.py`. Cada entrada é uma função que produz dados artificialmente, classificada pelo risco que representa numa apresentação.

| Classificação | Ocorrências | Significado |
|---|---|---|
| Crítico | 5 | Dado gerado exibido **sem identificação** — o espectador não tem como saber que é fictício |
| Sem marca | 5 | Gerador não declarado no código; invisível para a revisão |
| Declarado | 2 | Gerado, porém com procedência explícita — aceitável |

**Critério de aceite da revisão:** zero ocorrências em Crítico. Entradas em Declarado podem permanecer, desde que a justificativa esteja preenchida.

## Crítico — exibido sem identificação · 5


### `pagina_ml_deep_learning.py`

- **`_treinar_decision_tree()`** — linha 103
  - 1 chamada(s) de geração numa tela que NÃO identifica a procedência
  - *Ação:* decorar com @sintetico e chamar procedencia.selo() no topo da tela
- **`_treinar_isolation_forest()`** — linha 157
  - 3 chamada(s) de geração numa tela que NÃO identifica a procedência
  - *Ação:* decorar com @sintetico e chamar procedencia.selo() no topo da tela
- **`_simular_lstm_metricas()`** — linha 187
  - 3 chamada(s) de geração numa tela que NÃO identifica a procedência
  - *Ação:* decorar com @sintetico e chamar procedencia.selo() no topo da tela
- **`_shap_mock()`** — linha 251
  - 3 chamada(s) de geração numa tela que NÃO identifica a procedência
  - *Ação:* decorar com @sintetico e chamar procedencia.selo() no topo da tela

### `pagina_rafael.py`

- **`render()`** — linha 15
  - 5 chamada(s) de geração numa tela que NÃO identifica a procedência
  - *Ação:* decorar com @sintetico e chamar procedencia.selo() no topo da tela

## Sem marca — não declarado no código · 5


### `pagina_us05_gestor_frota.py`

- **`_check_api_health()`** — linha 176
  - 1 chamada(s) de geração; a tela identifica a procedência, mas a função não está declarada
  - *Ação:* decorar com @sintetico para aparecer no inventário

### `pagina_us07_subscricao_xai.py`

- **`_propostas_mock()`** — linha 42
  - 8 chamada(s) de geração; a tela identifica a procedência, mas a função não está declarada
  - *Ação:* decorar com @sintetico para aparecer no inventário
- **`_shap_proposta()`** — linha 79
  - 4 chamada(s) de geração; a tela identifica a procedência, mas a função não está declarada
  - *Ação:* decorar com @sintetico para aparecer no inventário

### `pagina_us08_analista_sinistros.py`

- **`_historico_sinistros_mock()`** — linha 42
  - 9 chamada(s) de geração; a tela identifica a procedência, mas a função não está declarada
  - *Ação:* decorar com @sintetico para aparecer no inventário
- **`_sinistros_pendentes_mock()`** — linha 66
  - 10 chamada(s) de geração; a tela identifica a procedência, mas a função não está declarada
  - *Ação:* decorar com @sintetico para aparecer no inventário

## Declarado — procedência explícita · 2


### `pagina_guilherme.py`

- **`_gerar_dataset_mock()`** — linha 23
  - 9 chamada(s) de geração, com declaração explícita
  - *Ação:* nenhuma — procedência declarada no código

### `pagina_us05_gestor_frota.py`

- **`_frota_mock_us05()`** — linha 107
  - 13 chamada(s) de geração, com declaração explícita
  - *Ação:* nenhuma — procedência declarada no código

## Como declarar procedência

```python
from core_procedencia import sintetico, real, selo

@sintetico("frota de demonstração",
           motivo="cadastro real ainda não disponível",
           substituir_por="data/frota_real.csv")
def _frota_demo():
    ...

# no topo da tela que exibe:
selo(_frota_demo._origem)
```

A função decorada entra no inventário automaticamente e a tela passa a exibir o aviso sem depender de o autor lembrar.
